﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Class1
/// </summary>
public class DataClass
{
    public String TestData1 { get; set; }
    public String TestData2 { get; set; }
    public String TestData3 { get; set; }
    public String TestData4 { get; set; }
    public String TestData5 { get; set; }
    public String TestData6 { get; set; }

	public DataClass()
	{

	}

}
